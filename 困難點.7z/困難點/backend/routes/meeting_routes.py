import logging
import json
import os
import urllib.parse
from flask import Blueprint, jsonify, request
import pandas as pd
from utils.meeting_utils import load_meeting_records
from utils.save_record import save_new_record, update_existing_record, delete_record
from utils.progress_manager import progress_manager
import uuid

logger = logging.getLogger(__name__)
meeting_bp = Blueprint("meeting", __name__)

@meeting_bp.route("/meeting_records", methods=["GET"])
def meeting_records():
    try:
        username = request.args.get("username", "").strip()
        data = load_meeting_records()
        logger.info(f"{username} 從後台抓取資料")
        return jsonify({"status": "success", "data": data})
    except Exception as e:
        logger.error(f"取得會議記錄失敗：{str(e)}")
        return jsonify({"status": "error", "message": str(e)}), 500


@meeting_bp.route("/add_record", methods=["POST"])
def add_record():
    username = request.args.get("username")
    if not username:
        return jsonify({"status": "error", "message": "缺少 username"}), 400

    try:
        new_record = request.get_json()
        new_record["id"] = str(uuid.uuid4())
        
        success = save_new_record(username, new_record)
        
        if success:
            return jsonify({
                "status": "success", 
                "message": "已新增", 
                "id": new_record["id"]
            })
        else:
            return jsonify({
                "status": "error", 
                "message": "新增失敗"
            }), 500
            
    except Exception as e:
        logger.error(f"新增記錄異常：{str(e)}")
        return jsonify({"status": "error", "message": str(e)}), 500


@meeting_bp.route("/update_record", methods=["PUT"])
def update_record():
    username = request.args.get("username")
    if not username:
        return jsonify({"status": "error", "message": "缺少 username"}), 400

    try:
        data = request.get_json()
        record_id = data.get("id") or data.get("項次")
        
        if not record_id:
            return jsonify({"status": "error", "message": "缺少記錄 ID 或項次"}), 400
        
        logger.info(f"準備更新記錄，ID/項次：{record_id}")
        
        # 如果包含進度紀錄，使用新的 JSON 檔案系統
        if "進度紀錄" in data:
            progress_data = data["進度紀錄"]
            
            if isinstance(progress_data, dict):
                # 儲存完整進度歷史到 JSON 檔案
                success = progress_manager.save_progress_history(record_id, progress_data)
                
                if success:
                    # 更新 CSV 中的進度紀錄（只保留最新一筆）
                    progress_manager.update_csv_progress(record_id)
                    
                    # 從 data 中移除進度紀錄，因為已經單獨處理
                    data_without_progress = {k: v for k, v in data.items() if k != "進度紀錄"}
                    
                    # 更新其他欄位
                    if data_without_progress:
                        update_success = update_existing_record(username, record_id, data_without_progress)
                        if not update_success:
                            return jsonify({"status": "error", "message": "更新其他欄位失敗"}), 500
                    
                    return jsonify({
                        "status": "success", 
                        "message": "更新成功", 
                        "id": record_id
                    })
                else:
                    return jsonify({"status": "error", "message": "進度紀錄儲存失敗"}), 500
        
        # 沒有進度紀錄的一般更新
        success = update_existing_record(username, record_id, data)
        
        if success:
            return jsonify({
                "status": "success", 
                "message": "更新成功", 
                "id": record_id
            })
        else:
            return jsonify({
                "status": "error", 
                "message": "更新失敗，找不到指定記錄"
            }), 500
            
    except Exception as e:
        logger.error(f"更新記錄異常：{str(e)}")
        return jsonify({"status": "error", "message": str(e)}), 500


@meeting_bp.route("/get_progress_history/<record_id>", methods=["GET"])
def get_progress_history(record_id):
    """取得指定記錄的完整進度歷史"""
    try:
        username = request.args.get("username", "").strip()
        progress_data = progress_manager.load_progress_history(record_id)
        
        logger.info(f"{username} 取得記錄 {record_id} 的進度歷史")
        return jsonify({
            "status": "success", 
            "data": progress_data
        })
        
    except Exception as e:
        logger.error(f"取得進度歷史失敗：{str(e)}")
        return jsonify({"status": "error", "message": str(e)}), 500


@meeting_bp.route("/add_progress", methods=["POST"])
def add_progress():
    """新增單筆進度記錄"""
    try:
        username = request.args.get("username")
        data = request.get_json()
        
        record_id = data.get("record_id")
        content = data.get("content")
        
        if not record_id or not content:
            return jsonify({"status": "error", "message": "缺少必要參數"}), 400
        
        # 新增進度記錄
        updated_progress = progress_manager.add_progress_entry(record_id, content)
        
        if updated_progress is not None:
            # 同時更新 CSV 中的最新進度
            progress_manager.update_csv_progress(record_id)
            
            return jsonify({
                "status": "success",
                "message": "進度記錄已新增",
                "progress_data": updated_progress
            })
        else:
            return jsonify({"status": "error", "message": "新增進度記錄失敗"}), 500
            
    except Exception as e:
        logger.error(f"新增進度記錄異常：{str(e)}")
        return jsonify({"status": "error", "message": str(e)}), 500


@meeting_bp.route("/delete_progress", methods=["DELETE"])
def delete_progress():
    """刪除單筆進度記錄"""
    try:
        username = request.args.get("username")
        record_id = request.args.get("record_id")
        timestamp = request.args.get("timestamp")
        
        if not record_id or not timestamp:
            return jsonify({"status": "error", "message": "缺少必要參數"}), 400
        
        # 刪除進度記錄
        updated_progress = progress_manager.remove_progress_entry(record_id, timestamp)
        
        if updated_progress is not None:
            # 同時更新 CSV 中的最新進度
            progress_manager.update_csv_progress(record_id)
            
            return jsonify({
                "status": "success",
                "message": "進度記錄已刪除",
                "progress_data": updated_progress
            })
        else:
            return jsonify({"status": "error", "message": "刪除進度記錄失敗"}), 500
            
    except Exception as e:
        logger.error(f"刪除進度記錄異常：{str(e)}")
        return jsonify({"status": "error", "message": str(e)}), 500




@meeting_bp.route("/delete_record/<record_id>", methods=["DELETE"])
def delete_record(record_id):
    username = request.args.get("username")
    if not username:
        return jsonify({"status": "error", "message": "缺少 username"}), 400

    try:
        # 1. 從 CSV 中刪除記錄
        csv_path = "static/MeetingRecording.csv"
        if os.path.exists(csv_path):
            df = pd.read_csv(csv_path, encoding="utf-8-sig")
            
            # 找到要刪除的記錄
            record_index = df[df['id'] == record_id].index
            
            if len(record_index) == 0:
                return jsonify({"status": "error", "message": "找不到要刪除的記錄"}), 404
            
            # 獲取項次以便刪除對應的 JSON 檔案
            item_number = df.loc[record_index[0], '項次']
            
            # 從 CSV 刪除記錄
            df = df.drop(record_index)
            df.to_csv(csv_path, index=False, encoding='utf-8-sig')

        # 2. 刪除對應的項次 JSON 檔案
        progress_dir = "static/progress_records"
        json_file_path = os.path.join(progress_dir, f"{item_number}.json")
        
        if os.path.exists(json_file_path):
            os.remove(json_file_path)
            logger.info(f"已刪除進度記錄檔案: {json_file_path}")

        logger.info(f"{username} 徹底刪除了記錄 {record_id}，項次: {item_number}")
        
        return jsonify({"status": "success", "message": "記錄已徹底刪除"})
        
    except Exception as e:
        logger.error(f"刪除記錄失敗: {str(e)}")
        return jsonify({"status": "error", "message": "刪除失敗"}), 500